#!/bin/bash

java -jar namechanger.jar $1 . .
