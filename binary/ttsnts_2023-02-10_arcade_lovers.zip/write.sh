#!/bin/bash

sudo flashrom -p linux_spi:dev=/dev/spidev0.0,spispeed=8000 -w $1
